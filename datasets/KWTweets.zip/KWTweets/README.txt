Note that due to the restrictions set by the tweets redistribution  developer policy (F. Be a Good Partner to Twitter), which in its number 2 states that �If you provide Content to third parties, including downloadable datasets of Content or an API that returns Content, you will only distribute or allow download of Tweet IDs, Direct Message IDs, and/or User IDs.�, we are not allowed to distribute the content of a tweet, though we may use its id to guarantee that researchers may access it in the future. Thus, instead of providing the tweet and the corresponding relevant keywords, we make available a text file whose name is the id of the tweet and whose contents are the corresponding relevant keywords as determined by the annotators . For instance, the file (910583891408424960.key) contains the gold keywords (�intersectionality�; �black women�; �Ericka Hart�; �life�; �impact of intersectionality�; �illustrate�) of the tweet identified with the id �910583891408424960�. In order to obtain the content of the tweet, researchers may use the GET statuses/show/:id feature. 

An alternative solution to this, is to make use of our code to download the tweets' textual content. To do so, usage: download_tweets.py [-h] [-r {lim,unlim}] [-v] -k APIKEY -ks APIKEY_SECRET -t TOKEN -ts TOKEN_SECRET

This code crawl the tweets' textual content of the KWTweets dataset. To do so, you need to use the API key and token of the Twitter Developer account.

Follow the below steps to generate access tokens for an existing app: 
1. Login to the developer portal on [1] (must have applied or have been approved) or [2] using your Twitter credentials.
2. Open the Twitter app for which you would like to generate access tokens. 
3. Navigate to the "Keys and Tokens" page. 
4. Select 'Create' under the "Access token & access token secret" section.
For more information, access [3].

optional arguments:
  -h, --help            show this help message and exit
  -r {lim,unlim}, --restricted {lim,unlim}
                        Limit the download to one tweet each 5 seconds. Default unlimited (unlim).
  -v, --version         show program's version number and exit

required arguments:
  -k APIKEY, --apikey APIKEY
                        The API key.
  -ks APIKEY_SECRET, --apikey_secret APIKEY_SECRET
                        The API key secret.
  -t TOKEN, --token TOKEN
                        The Access Tokens code.
  -ts TOKEN_SECRET, --token_secret TOKEN_SECRET
                        The Access Tokens secret.

REQUIREMENTS:
tweepy
tqdm

[1] https://developer.twitter.com/en/docs/basics/developer-portal/overview
[2] https://apps.twitter.com/
[3] https://developer.twitter.com/en/docs/basics/authentication/guides/access-tokens.html
