import tweepy
from argparse import ArgumentParser
from argparse import RawTextHelpFormatter
from glob import glob
from tqdm import tqdm
import os
from os import path
from math import ceil
from time import sleep

parser = ArgumentParser(description="This code crawl the tweets' textual content of the KWTweets dataset. To do so, you need to use the API key and token of the Twitter Developer account.\n\n" \
"Follow the below steps to generate access tokens for an existing app: \n" \
"1. Login to the developer portal on [1] (must have applied or have been approved) or [2] using your Twitter credentials.\n" \
"2. Open the Twitter app for which you would like to generate access tokens. \n" \
"3. Navigate to the \"Keys and Tokens\" page. \n" \
"4. Select 'Create' under the \"Access token & access token secret\" section.\n" \
"For more information, access [3].\n\n" \
"[1] https://developer.twitter.com/en/docs/basics/developer-portal/overview\n" \
"[2] https://apps.twitter.com/\n"\
"[3] https://developer.twitter.com/en/docs/basics/authentication/guides/access-tokens.html\n\n"\
"Created by Vítor Mangaravite" , formatter_class=RawTextHelpFormatter)

parser.add_argument('-r','--restricted', type=str, nargs=1, help='Limit the download to one tweet each 5 seconds. Default unlimited (unlim).', default=['unlim'], choices=['lim','unlim'])
parser.add_argument('-v', '--version', action='version',version="Version 1.0")

required_args = parser.add_argument_group('required arguments')
required_args.add_argument('-k', '--apikey', type=str, nargs=1, help='The API key.', required=True)
required_args.add_argument('-ks','--apikey_secret', type=str, nargs=1, help='The API key secret.', required=True)
required_args.add_argument('-t', '--token', type=str, nargs=1, help='The Access Tokens code.', required=True)
required_args.add_argument('-ts','--token_secret', type=str, nargs=1, help='The Access Tokens secret.', required=True)

args = parser.parse_args()

doc_path = path.join('.','docsutf8')
if not path.exists(doc_path):
    os.mkdir(doc_path)

# Continue download from last state
tweets_ids_already_done = set([ path.basename(doc_tweet_path).replace('.txt', '') for doc_tweet_path in glob(path.join(doc_path,'*')) ])
tweets_ids = list(filter(lambda x: path.basename(x).replace('.key', '') not in tweets_ids_already_done, glob(path.join('.','keys','*'))))

# As default, you can use twitter api with restriction of 180 requests each 15 min (~1 request each 5s)
time_per_tweets = ceil(15*60/180) if args.restricted[0] == 'lim' else 1

# To print undownloaded tweets
undownloaded = set()

auth = tweepy.OAuthHandler(args.apikey[0], args.apikey_secret[0])
auth.set_access_token(args.token[0], args.token_secret[0])    
api = tweepy.API(auth)

for dockey_path in tqdm(tweets_ids):
    docid = path.basename(dockey_path)
    doc_to_save_path = path.join(doc_path, docid.replace('.key','.txt'))
    try:
        doc_content = api.get_status(docid).text
    except:
        undownloaded.add(docid.replace('.key',''))
        continue
    with open(doc_to_save_path, 'w', encoding='utf8') as file_out:
        file_out.write(doc_content)
    sleep(time_per_tweets)

print("%d tweets couldn't be download. Probably they are private, were deleted or your apikey expired." % len(undownloaded))
print("Try access this content using the URLs:")
for tweetid in undownloaded:
    print("\thttps://twitter.com/statuses/%s" % tweetid)